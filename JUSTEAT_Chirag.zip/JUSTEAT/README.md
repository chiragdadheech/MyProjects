###Assignment -testing
## 
## Import the project as Maven Project.
## download the correct version of chromedriver as per the OS
## Set the correct path for chromedriver as per your system configuration
## Feature file where scenario is written in gherkin.
## Stepdefinitions file where all the methods for the steps mentioned. 
## Execute the project from TestRunner
## Right Click on the TestRunner and Run As Junit
