$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("/Users/varun/eclipse-workspace/JUSTEAT/src/main/java/Features/login.feature");
formatter.feature({
  "line": 2,
  "name": "use the website to find the resturants inoder to",
  "description": "order the food",
  "id": "use-the-website-to-find-the-resturants-inoder-to",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "line": 6,
  "name": "Search for resturant in my area",
  "description": "",
  "id": "use-the-website-to-find-the-resturants-inoder-to;search-for-resturant-in-my-area",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "I want food in area",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "I search for the resturants",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I should see some resturants in",
  "keyword": "Then "
});
formatter.match({
  "location": "loginstepDefination.i_want_food_in_area()"
});
formatter.result({
  "duration": 63704497771,
  "error_message": "java.lang.NoClassDefFoundError: Could not initialize class org.openqa.selenium.WebDriverException\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:603)\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:216)\n\tat org.openqa.selenium.remote.RemoteWebDriver.\u003cinit\u003e(RemoteWebDriver.java:136)\n\tat org.openqa.selenium.chromium.ChromiumDriver.\u003cinit\u003e(ChromiumDriver.java:75)\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:163)\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:150)\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:105)\n\tat stepDefinations.loginstepDefination.i_want_food_in_area(loginstepDefination.java:23)\n\tat ✽.Given I want food in area(/Users/varun/eclipse-workspace/JUSTEAT/src/main/java/Features/login.feature:8)\n",
  "status": "failed"
});
formatter.match({
  "location": "loginstepDefination.i_search_for_the_resturants()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "loginstepDefination.i_should_see_some_resturants_in()"
});
formatter.result({
  "status": "skipped"
});
});