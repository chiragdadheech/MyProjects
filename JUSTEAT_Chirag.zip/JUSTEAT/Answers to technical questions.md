Technical questions
Please answer the following questions in a markdown file called Answers to technical questions.md.

1.	How long did you spend on the technical test? What would you add to your solution if you had more time? If you didn't spend much time on the technical test then use this as an opportunity to explain what you would add.

I spent 1 to 1.5 hours on the test.
I would add explicit wait, also would have worked on POM/re-usability further.
I would have added Before/After annotations for better resources handling


2.	What do you think is the most interesting trend in test automation? 
javascript has been in trend, as the web development is also in javascript so the companies are leveraging JS in automation as well.
Frameworks like rest-assured is interesting in testing webservices thru code.

3.	How would you implement test automation in a legacy application? Have you ever had to do this? 
the automation concepts remain same, I have done it in QTP/UFT, perl language for legacy application, and used jmeter for rest APIs.

4.	How would you improve the customer experience of the JUST EAT website?
adding the "find my location" feature.
add a map (like fb marketplace) 
add a gift feature
caching my previous order list and giving suggestions based on it.
enable login from gmail
adding a chat window with artificial intelligence for customers

5.	Please describe yourself using JSON.
{
    "about": {
        "name": "CHIRAG DADHEECH",
		"sex": "male",
		"age": 30,
        "location": "CANADA",
        "designation": "SOFTWARE ENGINEER in Test",
       },
    "languages": ["java”, “python"]
}
