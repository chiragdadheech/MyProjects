package stepDefinitions;

import java.util.List;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

public class loginStepDefinition {

	WebDriver driver;
    String actual ="";
	@Given("^I want food in area$")
	public void i_want_food_in_area() {

		System.setProperty("webdriver.chrome.driver", "C:/Users/shloo/Desktop/JUSTEAT/chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://www.just-eat.co.uk/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}

	@When("^I search for the restaurants$")
	public void i_search_for_the_restaurants() throws InterruptedException {

		driver.findElement(By.xpath("//input[@name='postcode']")).sendKeys("AR51 1AA");
		String title = driver.getTitle();
		System.out.println("title= "+title);
		Assert.assertEquals("Order takeaway online from 30,000+ food delivery restaurants. | Just Eat", title);

		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}

	@Then("^I should see some restaurants in$")
	public void i_should_see_some_restaurants_in() {

		List<WebElement> list = driver.findElements(By.xpath("//h3[@class='c-listing-item-title']"));
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getText());
		}

		driver.findElement(By.xpath("//h3[contains(text(),'Demo - Subway Patel Premium Halal - Cookies')]")).click();
		actual= driver.getTitle();
		System.out.println(driver.getTitle());
		Assert.assertEquals("Demo - Subway Patel Premium Halal - Cookies restaurant menu in Borehamwood – Order from Just Eat", actual);
		driver.close();
	}

}
