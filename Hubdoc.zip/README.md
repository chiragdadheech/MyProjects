###Assignment -Xero
## This is a page object model framework, built utilizing the java, selenium library and Maven
## Java Robot class is used to interact with Window's file upload feature
## There are two page object classes created (LoginPage and HomePage)
## One TestNG class created TestScenarios
## Please follow below instructions to run the project:
## Import the project as Maven Project in the IDE of your choice (I used Eclipse)
## Download the correct version of chromedriver as per the OS
## Set the correct path for chromedriver in TestNG file TestScenarios.java (line 45) as per your system configuration
## Execute the project by right clicking on testng.xml and run as TestNG suite
## FilesToUpload folder contains 3 files which can be used to upload in tests
## change the file locations in the upload methods (clickBrowseAndUploadDocument and clickBrowseAndUploadMultipleDocuments) under HomePage class as per your local file location
## Once the test execution is over, the summary result can be seen on the console
## To see the html report: Go to test-output folder on the left panel and open "index.html"