/*
 * This java class contains the page objects of Login/Signup page  
 * and the methods to implement those page objects to perform the desired test operations.
 * HubDoc login page: https://app.hubdoc.com/login
 * Help Documentation:  https://t.lever-analytics.com/email-link?dest=https%3A%2F%2Fcentral.xero.com%2Fs%2Ftopic%2F0TO1N000001NcRDWA0%2Fmanage-documents-with-hubdoc%23business&eid=39025535-b7a7-4d4a-a05f-6fbcdd0fab23&idx=1&token=eci5RCoit2tWwGuHvqvS8ZDY3VU
 * Author: Chirag Dadheech
 */


package XeroProject.Hubdoc;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	WebDriver driver;

    By emailInput = By.id("email");
    By passwordInput = By.id("password");
    By signInBtn = By.id("btn-signin");
    
    public LoginPage(WebDriver driver){

        this.driver = driver;

    }

    //  Method to sign in
    public HomePage signInSecurely(){
    	     
    	     driver.findElement(emailInput).sendKeys("chiragdadheech999@gmail.com");
    	     driver.findElement(passwordInput).sendKeys("Gratitude1!");;
    	     driver.findElement(signInBtn).click();
          return PageFactory.initElements(driver, HomePage.class);

    }
    //To get the text of signin button and validate
    public String loginPageSignInBtn(WebDriver driver){
    	System.out.println("IN loginpage "+driver.findElement(signInBtn).getText());
            return (driver.findElement(signInBtn).getText());

    }
    
}
