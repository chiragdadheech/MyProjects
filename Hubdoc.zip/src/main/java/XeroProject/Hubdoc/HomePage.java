/*
 * This java class contains the page objects of Home page after logging in.  
 * and the methods to implement those page objects to perform the desired test operations.
 * HubDoc login page: https://app.hubdoc.com/login
 * Help Documentation:  https://t.lever-analytics.com/email-link?dest=https%3A%2F%2Fcentral.xero.com%2Fs%2Ftopic%2F0TO1N000001NcRDWA0%2Fmanage-documents-with-hubdoc%23business&eid=39025535-b7a7-4d4a-a05f-6fbcdd0fab23&idx=1&token=eci5RCoit2tWwGuHvqvS8ZDY3VU
 * Author: Chirag Dadheech
 */

package XeroProject.Hubdoc;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {

	WebDriver driver;

    By accountDropdown = By.cssSelector("i.fa.fa-user-circle");
    By logoutlink = By.cssSelector("a#logout-link.option");
    By uploadButton = By.cssSelector("button#add-receipt.btn.btn-large.btn-success");
    By browseBtn = By.cssSelector("div#uploadifive-file-upload");
    By allDocs = By.xpath("//div[@id='document-items']/div[@class='drag']");   
    By firstDocumentInTheList = By.xpath("//div[@id='document-items']/div[@class='drag'][1]");
    By amoutOfFirstDocInTheList = By.xpath("//div[@id='document-items']/div[@class='drag'][1]/a/div[@class='doc-details']/span[@class='amount']");
    By deleteLink = By.cssSelector("a.delete-btn.action");
    By deleteOkBtn =  By.cssSelector("a.btn.ok.btn-primary");
    By crossBtn = By.cssSelector("button.close-modal");   
    By addTagBtn = By.cssSelector("button.add-tag-btn.btn-mini.btn-success");
    By inputTag = By.cssSelector("input.add-tags");
    By allDocumentLink = By.xpath("//div[@class = 'nav-label'][@title = 'All Documents']");
    By dashboardUploadButton = By.cssSelector("div.dashboard-upload-icon.behaviour-icon");
    By newUploadedDoc = By.xpath("//span[@class='filename']");
    By editBtn = By.cssSelector("div#editor-button");
    By editAmtField = By.cssSelector("input#editor-amount.input-xlarge.required.editor-document-field");
    By editDocType= By.cssSelector("div#editor-document-type-div");
    By publishAndProceed = By.cssSelector("span.publish-and-next");
    By tagCaretToDelete = By.cssSelector("ul.tag-list li.drop div.selected.nav-label div.btn-group button.btn.dropdown-toggle.btn-mini.add-tag span.caret");
    By deleteTag = By.xpath("//a[@class='option delete'][text()='Delete Tag']");
    By tagListNumber = By.xpath("ul[@class='tag-list']/li[@class='drop']");
    By uploadCompleted = By.xpath("//span[@class='fileinfo'][text()=' - Completed']");
    int docsnumber = 0;
    
    public HomePage(WebDriver driver){

        this.driver = driver;

    }
    
    //To fech the text present on upload button , used in debugging
    public String getUploadBtnText(WebDriver driver){
    	System.out.println("IN HOMEPAGE METHOD "+driver.findElement(uploadButton).getText());
            return (driver.findElement(uploadButton).getText());

    }

   //   method to perform logout
    public LoginPage doLogout(WebDriver driver) {
          driver.findElement(accountDropdown).click();       
          driver.findElement(logoutlink).click();
          return PageFactory.initElements(driver, LoginPage.class);

    }
    //Method to click upload document button 
    public void clickUploadDocument(WebDriver driver) {
    	
        driver.findElement(uploadButton).click();
    	}
    
    //This method is used to upload a document in HubDoc
    public void clickBrowseAndUploadDocument(WebDriver driver) {
        System.out.print("print browser btn: "+driver.findElement(browseBtn).getText());
        driver.findElement(browseBtn).click();
        uploadFile("C:\\Users\\shloo\\Desktop\\filestoUpload\\Invoice");
    	WebDriverWait wait=new WebDriverWait(driver, 20);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(newUploadedDoc));
    	wait.until(ExpectedConditions.visibilityOfElementLocated(uploadCompleted));
    	System.out.print("new uploaded doc=  "+driver.findElement(newUploadedDoc).getText());
       
  }
    //This method is used to upload 3 documents in HubDoc
    public void clickBrowseAndUploadMultipleDocuments(WebDriver driver) {
        System.out.print("print browser btn: "+driver.findElement(browseBtn).getText());
        driver.findElement(browseBtn).click();
        uploadFile("\"C:\\\\Users\\\\shloo\\\\Desktop\\\\filestoUpload\\\\Invoice\" \"C:\\\\Users\\\\shloo\\\\Desktop\\\\filestoUpload\\\\Invoice2\" \"C:\\\\Users\\\\shloo\\\\Desktop\\\\filestoUpload\\\\Invoice3\"");
    	WebDriverWait wait=new WebDriverWait(driver, 20);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(newUploadedDoc));
    	wait.until(ExpectedConditions.visibilityOfElementLocated(uploadCompleted));
    	System.out.print("new uploaded doc=  "+driver.findElement(newUploadedDoc).getText());
       
  }
    
    //Upload document from dashboard upload button
    public void clickDashboardUploadDocument(WebDriver driver) {
    	
        driver.findElement(dashboardUploadButton).click();
    	}
    
    //This method returns the total number of documents present currently 
    public int totalDocuments(WebDriver driver)
    {
    	//driver.navigate().refresh();
    	WebDriverWait wait=new WebDriverWait(driver, 20);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(uploadButton));
    	wait.until(ExpectedConditions.visibilityOfElementLocated(firstDocumentInTheList));
    	
    	List <WebElement> docs = driver.findElements(allDocs);    	
    	docsnumber = docs.size();
    	return docsnumber;
    }
    
    //To close the upload document pop up 
    public void closePopup(WebDriver driver)
    {	WebDriverWait wait=new WebDriverWait(driver, 20);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(browseBtn));
    	wait.until(ExpectedConditions.visibilityOfElementLocated(crossBtn)).click();
        
    }
    
    
    //This method is to copy the file location to clipboard
	public void setClipboardData(String string) {
	
		   StringSelection stringSelection = new StringSelection(string);
		   Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
		}
	
   // Using Robot Class, we will interact with windows,  
   // this method paste the file location in upload window and press enter
	public void uploadFile(String fileLocation) {
        try {
      
            setClipboardData(fileLocation);
      
            Robot robot = new Robot();
	
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            
        } catch (Exception exp) {
        	exp.printStackTrace();
        }
    }
	
	
	public void pressEnter() {
        try {
        	 Robot robot = new Robot();
	        robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (Exception exp) {
        	exp.printStackTrace();
        }
    }
	//To click the first document present on the home page
    public void clickFirstDocumentInTheList(WebDriver driver) {
    	
        driver.findElement(firstDocumentInTheList).click();
    	}
    
    //Method to delete document
     public void deleteFirstDocument(WebDriver driver)
{	
	driver.findElement(deleteLink).click();
	driver.findElement(deleteOkBtn).click();
}

     //Method to add new tag
      public String addTagName(WebDriver driver, String tagname)
{	
	driver.findElement(addTagBtn).click();
	
	driver.findElement(inputTag).sendKeys(tagname);
	pressEnter();
	//Below we are returning newly created tag link's textname
	driver.findElement(By.xpath("//label[@title='"+tagname+"']")).click();
	return (driver.findElement(By.xpath("//label[@title='"+tagname+"']")).getText()); 
	
}

      //Method to count total document present in Trash
      public int totalDocumentsInTrash(WebDriver driver)
      {	WebDriverWait wait=new WebDriverWait(driver, 20);
      	wait.until(ExpectedConditions.visibilityOfElementLocated(uploadButton));
      	By trashLink = By.xpath("//label[text()='Trash']");
    	driver.findElement(trashLink).click();
      	List <WebElement> docs = driver.findElements(allDocs);    	
      	docsnumber = docs.size();
      	return docsnumber;
      }
      
      //To click the table (webelement) of trash docs
      public void clickAllDocuments(WebDriver driver)
      {
      	driver.findElement(allDocumentLink).click();

      }
      
      //Method to edit Document, update the amount and publish 
      public String editDocument(WebDriver driver) throws AWTException
      {
    	WebDriverWait wait=new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(editBtn));
      	driver.findElement(editBtn).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(editAmtField));
        driver.findElement(editAmtField).click();
      	Robot robot = new Robot();
    	
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_A);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
      
        driver.findElement(editAmtField).sendKeys("100");
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        
      	driver.findElement(publishAndProceed).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(firstDocumentInTheList));

      	driver.findElement(firstDocumentInTheList).click();
      	return driver.findElement(amoutOfFirstDocInTheList).getText();
      }            
      
      // Method to delete the tag
      public void deleteTag(WebDriver driver, String tagnameCreated)
      {
    	  driver.findElement(By.xpath("//label[@title='"+tagnameCreated+"']")).click();
    	  WebDriverWait wait=new WebDriverWait(driver, 20);
          wait.until(ExpectedConditions.visibilityOfElementLocated(tagCaretToDelete));
      	driver.findElement(tagCaretToDelete).click();
      	driver.findElement(deleteTag).click();
      	driver.findElement(deleteOkBtn).click();
      	}      
      
      //Method to find total number of tags present
      public int totalTagNumber(WebDriver driver)
      {
    	return driver.findElements(tagListNumber).size();
      	} 
}
