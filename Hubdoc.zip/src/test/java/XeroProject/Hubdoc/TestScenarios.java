/*
 * This is the TestNG class that contains the test scenarios to be performed on HubDoc.
 * Each test method is a test case.
 * Help Documentation:  https://t.lever-analytics.com/email-link?dest=https%3A%2F%2Fcentral.xero.com%2Fs%2Ftopic%2F0TO1N000001NcRDWA0%2Fmanage-documents-with-hubdoc%23business&eid=39025535-b7a7-4d4a-a05f-6fbcdd0fab23&idx=1&token=eci5RCoit2tWwGuHvqvS8ZDY3VU
 * Author: Chirag Dadheech
 */

package XeroProject.Hubdoc;

import java.awt.AWTException;
import java.util.NoSuchElementException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class TestScenarios {
	
     WebDriver driver;
     LoginPage objLogin= null ;
     HomePage objHome= null;
     String uploadBtnText = null;
     String signinTextValidate = null;
     int totalDocumentsBeforeUpload = 0;
     int totalDocumentsAfterUpload = 0;     
     int totalBeforeDelete = 0;
     int totalAfterDelete = 0;
     String tagName = null;
     
     
     //Set up method to initialize browser before each test
     @BeforeMethod
     public void setup(){

  /*	   System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\geckodriver.exe"); 
         driver = new FirefoxDriver();
    */
    	 
    	System.setProperty("webdriver.chrome.driver", "C:/Users/shloo/eclipse-workspace/chromedriver.exe");
 		driver = new ChromeDriver();
 		driver.get("https://app.hubdoc.com/login");
 		driver.manage().window().maximize();
 		driver.manage().deleteAllCookies();
 		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
 		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

    
	    }
     
     //after Method to quit browser after each method
     @AfterMethod
       public void closure(){
  	    driver.quit(); 
	      }
     
     
  @Test(priority=0)
  public void Test_Case_1_loginValidateHomePage() throws InterruptedException {
	  
	
		  objLogin = new LoginPage(driver); 
		  objHome = objLogin.signInSecurely();
	  
	  uploadBtnText = objHome.getUploadBtnText(driver);
	  System.out.println("INSCENARIOTEXT "+uploadBtnText);
	  Assert.assertEquals(uploadBtnText, "Upload Document");
	    }
    
  @Test(priority=1)
  public void Test_Case_2_validateLogoutFunctionality() throws InterruptedException {
	  
	  objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  System.out.println("logoutscenario INSCENARIOTEXT "+uploadBtnText);
      objLogin = objHome.doLogout(driver);
      signinTextValidate = objLogin.loginPageSignInBtn(driver);
      Assert.assertEquals(signinTextValidate, "Sign In Securely");

  }
  @Test(priority=2)
  public void Test_Case_3_validateBasicUploadFunctionality() throws InterruptedException {
	  objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  totalDocumentsBeforeUpload = objHome.totalDocuments(driver);
	  objHome.clickUploadDocument(driver);
      objHome.clickBrowseAndUploadDocument(driver);

      try
      {
    	  objHome.closePopup(driver);
      }
      catch(NoSuchElementException e)
       {
    	System.out.println(e.getMessage());  
       }


      objLogin = objHome.doLogout(driver);
      objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	 
      totalDocumentsAfterUpload = objHome.totalDocuments(driver);
	  System.out.print("before: "+totalDocumentsBeforeUpload+",  afterUpload: "+totalDocumentsAfterUpload);
	  Assert.assertEquals(totalDocumentsBeforeUpload+1, totalDocumentsAfterUpload );

  }
  
  @Test(priority=3)
  public void Test_Case_4_validateDeleteDocumentFunctionality() throws InterruptedException {
	  objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  totalBeforeDelete = objHome.totalDocuments(driver);
	  objHome.clickFirstDocumentInTheList(driver);
	  objHome.deleteFirstDocument(driver);	  
      
      objLogin = objHome.doLogout(driver);
      objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	 
      totalAfterDelete = objHome.totalDocuments(driver);
	  System.out.println("before delete : "+totalBeforeDelete+",  after delete: "+totalAfterDelete);
	  Assert.assertEquals(totalBeforeDelete-1, totalAfterDelete );

  }
  
  @Test(priority=4)
  public void Test_Case_5_validateAddTagFunctionality() throws InterruptedException {
	  objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  int randomnumber = ThreadLocalRandom.current().nextInt(); 
	  String tagNameToCreate = "Tag"+randomnumber;
	  objHome.clickFirstDocumentInTheList(driver);
	  String tagNameCreated = objHome.addTagName(driver, tagNameToCreate);	  
	  System.out.println("tagNameToCreate : "+tagNameToCreate+",  tagNameCreated: "+tagNameCreated);

       Assert.assertEquals(tagNameCreated, tagNameToCreate );

  }
  
  @Test(priority=5)
  public void Test_Case_6_validateDeletedDocumentGoesToTrash() throws InterruptedException {
	  objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  totalBeforeDelete = objHome.totalDocumentsInTrash(driver);
	  objHome.clickAllDocuments(driver);
	  objHome.clickFirstDocumentInTheList(driver);
	  objHome.deleteFirstDocument(driver);	  
      
      objLogin = objHome.doLogout(driver);
      objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	 
      totalAfterDelete = objHome.totalDocumentsInTrash(driver);
	  System.out.println("before delete : "+totalBeforeDelete+",  after delete: "+totalAfterDelete);
	  Assert.assertEquals(totalBeforeDelete+1, totalAfterDelete );

  }
  @Test(priority=6)
  public void Test_Case_7_validateUploadFromDashboardUploadButton() {
	  objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  totalDocumentsBeforeUpload = objHome.totalDocuments(driver);
	  objHome.clickDashboardUploadDocument(driver);
      objHome.clickBrowseAndUploadDocument(driver);
      try
      {
      objHome.closePopup(driver);
      }
      catch(NoSuchElementException e)
       {
    	System.out.println(e.getMessage());  
       }

      
      objLogin = objHome.doLogout(driver);
      objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	 
      totalDocumentsAfterUpload = objHome.totalDocuments(driver);
	  System.out.println("before: "+totalDocumentsBeforeUpload+",  afterUpload: "+totalDocumentsAfterUpload);
	  Assert.assertEquals(totalDocumentsBeforeUpload+1, totalDocumentsAfterUpload );

  }
  @Test(priority=7)
  public void Test_Case_8_editDocumentManuallyEnterDocumentAmount() throws InterruptedException, AWTException {
	  objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  totalDocumentsBeforeUpload = objHome.totalDocuments(driver);
	  objHome.clickUploadDocument(driver);
      objHome.clickBrowseAndUploadDocument(driver);

      try
      {
      objHome.closePopup(driver);
      }
      catch(NoSuchElementException e)
       {
    	System.out.println(e.getMessage());  
       }

      
      objLogin = objHome.doLogout(driver);
      objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  objHome.clickFirstDocumentInTheList(driver);     
      Assert.assertEquals(objHome.editDocument(driver), "$100.00 USD");
	  
  }
 
  //Upload three files in below method and validate the count	
  @Test(priority=8)
  public void Test_Case_9_validateMultipleFilesUploadFunctionality() throws InterruptedException {
	  objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  totalDocumentsBeforeUpload = objHome.totalDocuments(driver);
	  objHome.clickUploadDocument(driver);
      objHome.clickBrowseAndUploadMultipleDocuments(driver);       
      try
      {
      objHome.closePopup(driver);
      }
      catch(NoSuchElementException e)
       {
    	System.out.println(e.getMessage());  
       }
      objLogin = objHome.doLogout(driver);
      objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	 
      totalDocumentsAfterUpload = objHome.totalDocuments(driver);
	  System.out.print("before: "+totalDocumentsBeforeUpload+",  afterUpload: "+totalDocumentsAfterUpload);
	  Assert.assertEquals(totalDocumentsBeforeUpload+3, totalDocumentsAfterUpload );

  }
  
  
  /*@Test(priority=9)
  public void Test_Case_10_validateDeleteTagFunctionality() throws InterruptedException {
	  objLogin = new LoginPage(driver); 
	  objHome = objLogin.signInSecurely(); 
	  int randomnumber = ThreadLocalRandom.current().nextInt(); 
	  String tagNameToCreate = "Tag"+randomnumber;
	  objHome.clickFirstDocumentInTheList(driver);
	  
	  //below function creates tag, clicks on it and returns its name, 
	  //so that then we can validate with assert
	 
	  String tagNameCreated = objHome.addTagName(driver, tagNameToCreate);	  
	  System.out.println("tagNameToCreate : "+tagNameToCreate+"tagNameCreated: "+tagNameCreated);
     
	  totalBeforeDelete = objHome.totalTagNumber(driver);
	  objHome.deleteTag(driver, tagNameCreated);
	  totalAfterDelete	= objHome.totalTagNumber(driver);

       Assert.assertEquals(totalBeforeDelete - 1, totalAfterDelete );
       
  }  
  */
  
}
