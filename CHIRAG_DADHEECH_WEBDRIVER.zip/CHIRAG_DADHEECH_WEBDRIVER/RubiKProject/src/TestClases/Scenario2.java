package TestClases;

import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import WebClasses.CarbonImpactPage;

public class Scenario2 {
	
     WebDriver driver;
     CarbonImpactPage CIPage ;
     String countryWithRankTwo = null;
     
     @BeforeMethod
     public void setup(){
//  	   System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\geckodriver.exe"); 
//       driver = new FirefoxDriver();
       
       System.setProperty("webdriver.chrome.driver","C:\\Users\\cdadheech\\Downloads\\chromedriver_win32\\chromedriver.exe");  
       driver=new ChromeDriver();  
       driver.manage().window().maximize();
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       
       driver.get("https://www.tesla.com/en_CA/carbonimpact");
      
	    }
     @AfterMethod
     public void closure(){
  	 driver.quit(); 
	    }
     
  @Test(priority=0)
  public void Scenario_2_Test_Case_1_ValidateCountryRank2() throws InterruptedException {
	  CIPage = new CarbonImpactPage(driver);
	  countryWithRankTwo = CIPage.validateSecondRankCountry();
	  System.out.println("Country with rank 2 = "+countryWithRankTwo+"\n\n");
	  Assert.assertEquals(countryWithRankTwo, "Canada");
  }
   
  @Test(priority=1)
  public void Scenario_2_Test_Case_2_findCanadaRank() throws InterruptedException {
	  CIPage = new CarbonImpactPage(driver);
	  CIPage.getCanadaRank();
	  }
}
