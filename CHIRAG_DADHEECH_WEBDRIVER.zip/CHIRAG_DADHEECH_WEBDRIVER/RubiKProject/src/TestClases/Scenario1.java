package TestClases;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import WebClasses.HomePage;
import WebClasses.AutopilotPage;

public class Scenario1 {
	
     WebDriver driver;
     HomePage objHome;
     String autoPilotRate = null;
     AutopilotPage Apobj= null;
     @BeforeMethod
     public void setup(){
//  	   System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\geckodriver.exe"); 
//       driver = new FirefoxDriver();
       
       System.setProperty("webdriver.chrome.driver","C:\\Users\\cdadheech\\Downloads\\chromedriver_win32\\chromedriver.exe");  
       driver=new ChromeDriver();  
       driver.manage().window().maximize();
       
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       driver.get("https://www.tesla.com/en_ca/models/design#battery​");
      
	    }
     @AfterMethod
     public void closure(){
  	 driver.quit(); 
	    }
     
  @Test(priority=0)
  public void Scenario_1_Test_Case_1_ValidateAutopilotRate() throws InterruptedException {
	  
	  objHome = new HomePage(driver);
	  Apobj = objHome.clickAutopilot();
	  autoPilotRate = Apobj.validateAutopilotRate(driver);
	  Assert.assertEquals(autoPilotRate, "$118,290");
	  

  }
  
  
  
}
