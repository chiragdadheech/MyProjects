package WebClasses;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class AutopilotPage {

	WebDriver driver;
    String purchasePrice = null;
    By autoPilotLink = By.xpath("//ul[@class='packages-options--nav-list']/li[4]/h2[@class='packages-options--nav-title']");
    By checkBoxOption = By.cssSelector("i.icon-checkbox.option-checkbox--icon.icon-checkbox--blue");
    By purchasePriceValue = By.cssSelector("p.finance-item--price.finance-item--price-before-savings");
    
    
    public AutopilotPage(WebDriver driver){

        this.driver = driver;

    }


    public String validateAutopilotRate(WebDriver driver){
    	 purchasePrice = driver.findElement(purchasePriceValue).getText();
    	 System.out.println("Purchase price without autopilot option: "+purchasePrice);
    	 Actions actions = new Actions(driver);
         actions.moveToElement(driver.findElement(checkBoxOption)).perform();
   	     driver.findElement(checkBoxOption).click();
    	 purchasePrice = driver.findElement(purchasePriceValue).getText();
         System.out.println("Purchase price after checking autopilot option: "+purchasePrice);
         return purchasePrice;
    }
    
}
