package WebClasses;

import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class CarbonImpactPage {


	WebDriver driver;
	String rank = null, country = null;
	Map<String, String> rankCountry = new HashMap<>();
    String countryRank2 = null;
    By worldTab = By.cssSelector("li.nav-world ");
    By secondCountry = By.xpath("//section[@class='leaderboard-world']//section[@class='list']//div[2]/span[2]/span[@class='country-name']");
    By canadaRank = By.xpath("//section[@class='leaderboard-world']//section[@class='list']//div//span[@class='country-name'][text()=Canada]");
    byte i = 1;
    
    public CarbonImpactPage(WebDriver driver){

        this.driver = driver;

    }


    public String validateSecondRankCountry(){

    	   Actions actions = new Actions(driver);
           actions.moveToElement(driver.findElement(worldTab)).perform();
            driver.findElement(worldTab).click();
            countryRank2 = driver.findElement(secondCountry).getText();
            return countryRank2;

    }
  
    public void getCanadaRank(){
    	Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(worldTab)).perform();
        driver.findElement(worldTab).click();
        
        try
        {
          for(;;i++)   //Since we are using try-catch, infinite loop will end at the end of the table
            {
           rank = driver.findElement(By.xpath("//section[@class='leaderboard-world']//section[@class='list']//div["+i+"]//span[1]")).getText();
           country = driver.findElement(By.xpath("//section[@class='leaderboard-world']//section[@class='list']//div["+i+"]//span[2]")).getText();
           rankCountry.put(rank, country); 
           
            }
        }
        catch(Exception e)  // Try-catch is used to identify all the elements in the table 
                            // and come out of loop once all the elements are over. 
          {
        	System.out.println(e.getStackTrace()+"   "+e.getMessage());
        
          }
        rankCountry.forEach( (key, value) -> {
        	if (value.equals("Canada"))
            System.out.println("\nRank of "+ value + " is: "+ key);
        });
    }
}


