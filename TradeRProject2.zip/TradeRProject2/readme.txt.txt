Versions Used:

firefox version used = 71.0b10 (64-bit)
selenium Webdriver = selenium-java-3.141.59
geckodriver71.0.0.7222
java = Java(TM) SE Runtime Environment (build 1.8.0_221-b11)
Eclipse IDE = Version: 2019-09 R (4.13.0)

Framework created = Page Object Model (3 pageObjects classes and 3 test classes)

To run the tests:
1. open the project in eclipse, add external jars of selenium WebDriver (present in the folder "ExternalJars")
2. Give correct path of geckodriver.exe as per your system	
3. right click on testng.xml file and 'run as': "TestNG Suite"
4. For ny information/ clarification, please reach out to me, I will explain all the validation points and the logics used.

Best Regards,
Chirag