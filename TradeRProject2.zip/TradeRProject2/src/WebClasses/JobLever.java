package WebClasses;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class JobLever {

	WebDriver driver;
	By filterText = By.cssSelector("span.medium-utility-label.filter-by-label");
    By filterCity = By.cssSelector("div.content-wrapper.list-page div.filter-bar div.filter-button-wrapper");
    By filterTeam= By.xpath("//div[@class='filter-bar']/div[2]");
    By EngResult = By.xpath("//ul/li[2]/a[text()='Engineering']");
    By TorontoResult = By.xpath("//ul/li[11]/a[@class='category-link'][text()='Toronto, Ontario, Canada']");
	By applyBtn = By.xpath("//a[text()='Apply']");
	By srcResults = By.xpath("//span[text()='Toronto, Ontario, Canada']");
	By teamResults = By.partialLinkText("ENGINEERING");
	
	int applyBtnCount = 0;
    int srcResultCount = 0;
    int teamResultCount = 0;
    public JobLever(WebDriver driver){

        this.driver = driver;

    }
    
    public String getFilterText(WebDriver driver){
    	System.out.println(driver.findElement(filterText).getText());
            return (driver.findElement(filterText).getText());

    }
    
    public int[] filterByCity(WebDriver driver) throws InterruptedException{
        driver.findElement(filterCity).click();
        Thread.sleep(2000);
        
        System.out.println(driver.findElement(TorontoResult).getText());
         Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(TorontoResult)).perform();

        driver.findElement(TorontoResult).click();     
        driver.navigate().refresh();
        List<WebElement> allApplyBtn = driver.findElements(applyBtn); 
        for(WebElement w : allApplyBtn) {
            System.out.println(applyBtnCount+w.getText());

           applyBtnCount++;
        }
        
        
        List<WebElement> AllsrcResults = driver.findElements(srcResults); 
        for(WebElement w : AllsrcResults) {
            System.out.println(srcResultCount+w.getText());

           srcResultCount++;
        }
        int[] res = new int[2]; 
        res[0] = applyBtnCount;
        res[1] = srcResultCount;
        
        return res;

    }
    
    public int[] filterByCityAndTeam(WebDriver driver) throws InterruptedException{
        driver.findElement(filterCity).click();
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(TorontoResult)).perform();
        driver.findElement(TorontoResult).click();     
        driver.findElement(filterTeam).click();
        driver.findElement(EngResult).click();
       
        driver.navigate().refresh();
        List<WebElement> allApplyBtn = driver.findElements(applyBtn); 
        for(WebElement w : allApplyBtn) {
            System.out.println(applyBtnCount+w.getText());

           applyBtnCount++;
        }
        
        
        List<WebElement> AllsrcResults = driver.findElements(srcResults); 
        for(WebElement w : AllsrcResults) {
            System.out.println(srcResultCount+w.getText());

           srcResultCount++;
        }
        
        List<WebElement> AllteamResults = driver.findElements(teamResults); 
        for(WebElement w : AllteamResults) {
            System.out.println(teamResultCount+w.getText());

            teamResultCount++;
        }
        
        int[] res = new int[3]; 
        res[0] = applyBtnCount;
        res[1] = srcResultCount;
        res[2] = teamResultCount;
        
        return res;

    }
}
