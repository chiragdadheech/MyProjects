package WebClasses;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	WebDriver driver;

    By careersLink = By.linkText("Careers");
    
    CareerPage cp = new CareerPage(driver);
    
    public HomePage(WebDriver driver){

        this.driver = driver;

    }


    public CareerPage clickCareers(){
    	     driver.findElement(careersLink).click();
          return PageFactory.initElements(driver, CareerPage.class);

    }
    
}
