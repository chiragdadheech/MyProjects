package WebClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class CareerPage {


	WebDriver driver;

    By caOpportunities = By.cssSelector(".job-links__button.job-links__button--ca");
    By headTitle = By.cssSelector("span.header__title");
    
    public CareerPage(WebDriver driver){

        this.driver = driver;

    }


    public JobLever clickCaOpportunities(WebDriver driver){
    	
            driver.findElement(caOpportunities).click();
            return PageFactory.initElements(driver, JobLever.class);

    }
    public String getheaderTitle(WebDriver driver){
    	System.out.println(driver.findElement(headTitle).getText());
            return (driver.findElement(headTitle).getText());

    }

}
