package TestClases;

import java.util.Set;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import WebClasses.CareerPage;
import WebClasses.HomePage;
import WebClasses.JobLever;

public class Scenario1 {
	
     WebDriver driver;
     CareerPage objCareer ;
     HomePage objHome;
     JobLever jlever;
     String careersTitle = null;
     String parentWindowHandle = null;
     String lastWindowHandle = null;
     Set<String> allWindowHandles = null; 
     String filterText = null;	 
     @BeforeMethod
     public void setup(){
  	   System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\geckodriver.exe"); 
       driver = new FirefoxDriver();
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       driver.get("https://www.traderev.com/en-ca/");
      
	    }
     @AfterMethod
     public void closure(){
  	 driver.quit(); 
	    }
  @Test(priority=0)
  public void Scenario_1_Test_Case_1_ValidateCareersPage() throws InterruptedException {
	  
	  System.out.println("Parent window's handle -> " + parentWindowHandle);	 
	  objHome = new HomePage(driver);
	  objCareer = objHome.clickCareers();
	  Thread.sleep(2000);
	  allWindowHandles = driver.getWindowHandles();

	  for(String handle : allWindowHandles)
		{
			System.out.println("Window handle - > " + handle);
			lastWindowHandle = handle;
			  Thread.sleep(1000);


		}
	 
	  driver.switchTo().window(lastWindowHandle);
	  careersTitle =  objCareer.getheaderTitle(driver);
	  System.out.println(careersTitle);
	  Assert.assertEquals("Reinventing automotive sales", careersTitle);
	  

  }
  
  @Test(priority=1)
  public void Scenario_2_Test_Case_2_validateCAJobsite() throws InterruptedException {
	  
	  System.out.println("Parent window's handle -> " + parentWindowHandle);	 
	  objHome = new HomePage(driver);
	  objCareer = objHome.clickCareers();
	  Thread.sleep(2000);
	  allWindowHandles = driver.getWindowHandles();

	  for(String handle : allWindowHandles)
		{
			System.out.println("Window handle - > " + handle);
			lastWindowHandle = handle;
		  Thread.sleep(2000);

		}
	 
	  driver.switchTo().window(lastWindowHandle);

	  careersTitle =  objCareer.getheaderTitle(driver);
	  jlever = objCareer.clickCaOpportunities(driver);
	  Thread.sleep(1000);
	  allWindowHandles = driver.getWindowHandles();

	  for(String handle : allWindowHandles)
		{
			System.out.println("Window handle - > " + handle);
			lastWindowHandle = handle;
			Thread.sleep(1000);
		} 
	  
	  driver.switchTo().window(lastWindowHandle);
	  filterText = jlever.getFilterText(driver);
	  System.out.println(filterText);
	  Assert.assertEquals("FILTER BY:", filterText);

	  
  }
  
  
}
