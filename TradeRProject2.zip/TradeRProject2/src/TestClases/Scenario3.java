package TestClases;

import org.testng.annotations.Test;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import WebClasses.CareerPage;
import WebClasses.HomePage;
import WebClasses.JobLever;

public class Scenario3 {
	
     WebDriver driver;
     CareerPage objCareer ;
     HomePage objHome;
     JobLever jlever;
     String careersTitle = null;
     String parentWindowHandle = null;
     String lastWindowHandle = null;
     Set<String> allWindowHandles = null; 
     String filterText = null;
     
     @BeforeMethod
     public void setup(){
  	   System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\geckodriver.exe"); 
       driver = new FirefoxDriver();
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       driver.get("https://jobs.lever.co/traderev");
      
	    }
     @AfterMethod
     public void closure(){
  	 driver.quit(); 
	    }
  @Test(priority=0)
  public void Scenario_3_Test_Case_1_ValidateCityAndTeamResults() throws InterruptedException {
	  int[] result = new int[3];
	  jlever = new JobLever(driver);
	  result = jlever.filterByCityAndTeam(driver);
	  System.out.println("Total results = "+result[0]+", Total ApplyLinks = "+ result[1]+", total team=" + result[2]);
	  Assert.assertEquals(result[0], result[1]);
	  Assert.assertEquals(result[2], result[1]);

  }
   
}
